﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharedClasses
{
    [Serializable]
    public class EventObject : Reminder
    {
        int starts;
        int ends;
        int not;
        string description;
        public EventObject(int day, int month, int year, string name, int starts, int ends, int not, string description) :base (name, day, month, year,starts)
        {
            this.starts = starts;
            this.ends = ends;
            this.not = not;
            this.description = description;
        }
        public int Ends
        {
            get
            {
                return this.ends;
            }
        }
        public int Notification
        {
            get
            {
                return this.not;
            }
        }
        public string Description
        {
            get
            {
                return this.description;
            }
        }

    }
}
