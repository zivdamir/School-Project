﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharedClasses
{
    [Serializable]
    public class Reminder
    {
        protected int day;
        protected int month;
        protected int year;
        protected string name;
        protected int starts;
        public Reminder (string name,int day, int month, int year,int starts) 
        {
            this.day = day;
            this.month = month;
            this.year = year;
            this.name = name;
            this.starts = starts;
        }
        public int Month
        {
            get
            {
                return this.month;
            }
        }
        public int Year
        {
            get
            {
                return this.year;
            }
        }
        public int Day
        {
            get
            {
                return this.day;
            }
        }
        public string Name
        {
            get
            {
                return this.name;
            }
        }
        public int Starts
        {
            get
            {
                return this.starts;
            }
        }

    }
}
